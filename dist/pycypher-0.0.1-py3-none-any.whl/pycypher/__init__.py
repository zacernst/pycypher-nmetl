# -*- coding: utf-8 -*-

__VERSION__ = "0.0.1"
